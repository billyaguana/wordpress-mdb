<?php
/**
 * under_theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package under_theme
 */

/**
 * Enqueue scripts and styles.
 */

/***************************
    DEFAULT
****************************/

/***************************
    FEATURED IMAGE
****************************/
add_theme_support( 'post-thumbnails' ); 


function site_scripts_styles() {
    $assets = get_template_directory_uri() . '/assets/';
    $version = '20190401';
    
    $mdb = 'mdb476';
    $mdb_assets = $assets . $mdb;
    
    $bootstrap = 'bootstrap431';   
    $bs_assets = $assets . $bootstrap;    

    //fontawesome
    wp_register_style('fontawesome', 'https://use.fontawesome.com/releases/v5.8.1/css/all.css');    
    wp_enqueue_style('fontawesome');
    
    //jquery
    wp_register_script('jquery_js', $assets . 'js/jquery-3.3.1.min.js');
    wp_enqueue_script('jquery_js','','','',$in_footer=true);
    
    //bootstrap
    wp_register_script('popper_js', $bs_assets . '/js/popper.min.js');
    wp_register_script('bootstrap_js', $bs_assets . '/js/bootstrap.min.js');    
    wp_register_style('bootstrap_css', $bs_assets . '/css/bootstrap.min.css');    
    
    //material design
    wp_register_script('mdb_bootstrap_js', $mdb_assets . '/js/mdb.min.js');        
    wp_register_style('mdb_bootstrap_css', $mdb_assets . '/css/mdb.lite.min.css');    
    
    wp_enqueue_script('popper_js','','','',$in_footer=true);
    wp_enqueue_script('bootstrap_js','','','',$in_footer=true);
    wp_enqueue_style('bootstrap_css');        
    
    wp_enqueue_style('mdb_bootstrap_css');    
    wp_enqueue_script('mdb_bootstrap_js','','','',$in_footer=true);        
    

    //website main JS scripts and other scripts here
    wp_register_script('main_js', $assets . 'js/script.js');
    wp_enqueue_script('main_js','','','',$in_footer=true);                
    
    //website script CSS here
    
    
    //main theme
	wp_enqueue_style('under_theme-style', get_stylesheet_uri());
    
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}    
    
}

add_action( 'wp_enqueue_scripts', 'site_scripts_styles' );    


/***************************
    PLACEHOLDER IMG THUMB
****************************/
// usage : echo use_placeholder(); 

function use_placeholder () {
   if (has_post_thumbnail()) {
       return the_post_thumbnail($size = 'large', ['class' => 'img-responsive responsive-full z-depth-1']);
   } else {
       $image = '<img src="' . get_template_directory_uri() . 
                '/assets/images/placeholder.jpg" alt="placeholder" class="z-depth-1">';
       return $image;
   }
}


/***************************
    WIDGET AREA
****************************/
//dynamic_sidebar('sidebar-1');

function under_theme_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'under_theme' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'under_theme' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'under_theme_widgets_init' );



/***************************
    BOOTSTRAP NAV WALKER
****************************/
//usage :
/*
        wp_nav_menu( array(
            'theme_location'  => 'top',
            'depth'	          => 2, // 1 = no dropdowns, 2 = with dropdowns.
            'container'       => '',
            'container_class' => '',
            'container_id'    => '',
            'menu_class'      => 'navbar-nav mr-auto',
            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
            'walker'          => new WP_Bootstrap_Navwalker(),
        ) );
*/

if ( ! file_exists( get_template_directory() 
                   . '/class-wp-bootstrap-navwalker.php' ) ) {
	// file does not exist... return an error.
	return new WP_Error( 'class-wp-bootstrap-navwalker-missing', __( 'It appears the class-wp-bootstrap-navwalker.php file may be missing.', 'wp-bootstrap-navwalker' ) );
} else {
	// file exists... require it.
	require_once get_template_directory() 
        . '/class-wp-bootstrap-navwalker.php';
}
register_nav_menu('top', 'Top menu'); 

/***************************
        PAGINATION
****************************/
// usage
/*
    <div class="post-pagination  clearfix">
        <?php pp_pagination_nav(); ?>
    </div>
*/


function pp_pagination_nav() {
	if( is_singular() )
	return;
	
	global $wp_query;
	
	/** Stops execution if there's only 1 page */
	if( $wp_query->max_num_pages <= 1 )
	return;
	
	$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
	$max = intval( $wp_query->max_num_pages );
	
	/** Adds current page to the array */
	if ( $paged >= 1 )
	$links[] = $paged;
	
	/** Add the pages around the current page to the array */
	if ( $paged >= 3 ) {
	$links[] = $paged - 1;
	$links[] = $paged - 2;
	}
	
	if ( ( $paged + 2 ) <= $max ) {
	$links[] = $paged + 2;
	$links[] = $paged + 1;
	}
	
	echo '<div class=""><ul class="pagination text-left">' . "\n";
	
	/** Previous Post Link Function */
	if ( get_previous_posts_link() )
		printf( '<li>%s</li>' . "\n", get_previous_posts_link($label = '<i class="fa fa-angle-double-left"></i>') );
	
	/** Links to the first page, plus ellipses if necessary */
	if ( ! in_array( 1, $links ) ) {
		$class = 1 == $paged ? ' class="active"' : '';
		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );
		if ( ! in_array( 2, $links ) )
		echo '<li>…</li>';
	}
	
	/** Links to current page, plus 2 pages in either direction if necessary */
	sort( $links );
	foreach ( (array) $links as $link ) {
		$class = $paged == $link ? ' class="active"' : '';
		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
	}
	
	/** Links to last page, plus ellipses if necessary */
	if ( ! in_array( $max, $links ) ) {
	if ( ! in_array( $max - 1, $links ) )
		echo '<li>…</li>' . "\n";
		$class = $paged == $max ? ' class="active"' : '';
		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
	}
	
	/** Next Post Link function */
	if ( get_next_posts_link() )
		printf( '<li>%s</li>' . "\n", get_next_posts_link($label = '<i class="fa fa-angle-double-right"></i>') );
	echo '</ul></div>' . "\n";
}

/***************************
        CUSTOM SEARCH
****************************/
/* passive */
if (!is_admin()) {
    function wpb_search_filter($query) {
    if ($query->is_search) {
      $query->set('post_type', 'post');
    }
      return $query;
    }
      add_filter('pre_get_posts','wpb_search_filter');
}


/***************************
        TEXT LIMITER
****************************/
//usage : echo limitStrlen(get_the_title());

function limitStrlen($input, $length, $ellipses = true, $strip_html = true) {
    //strip tags, if desired
    if ($strip_html) {
        $input = strip_tags($input);
    }

    //no need to trim, already shorter than trim length
    if (strlen($input) <= $length) {
        return $input;
    }

    //find last space within length
    $last_space = strrpos(substr($input, 0, $length), ' ');
    if($last_space !== false) {
        $trimmed_text = substr($input, 0, $last_space);
    } else {
        $trimmed_text = substr($input, 0, $length);
    }
    //add ellipses (...)
    if ($ellipses) {
        $trimmed_text .= '...';
    }

    return $trimmed_text;
}

//usage : echo limit_text(get_the_excerpt()(), 100); //100 words
function limit_text($text, $limit) {
      if (str_word_count($text, 0) > $limit) {
          $words = str_word_count($text, 2);
          $pos = array_keys($words);
          $text = substr($text, 0, $pos[$limit]) . '...';
      }
      return $text;
    }