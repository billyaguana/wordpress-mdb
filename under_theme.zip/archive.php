<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package under_theme
 */

get_header();
?>
<div class="container"> <!-- remove this if you want a fluid container -->
    <div class="row">
    <div class="col-lg-8">
	<div id="primary" class="content-area">
		<main id="main" class="site-main">

            <?php get_template_part( 'template-parts/archive', 'custom' ); ?>
            
            <?php 
            /*
                If you will use Ajax Load More
                echo do_shortcode( '[ajax_load_more post_type="post" scroll="false"]' ); 
             */ 
            ?>       
                    
		</main><!-- #main -->
	</div><!-- #primary -->
    </div> <!-- col 8 -->        
        
    <div class="col-lg-4">
        <?php get_sidebar(); ?>
    </div>
    </div> <!-- row -->       
</div>
<?php get_footer(); ?>
