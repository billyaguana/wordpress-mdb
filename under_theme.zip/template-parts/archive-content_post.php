<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package under_theme
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="row mb-5">
  <div class="col-lg-4 post-thumbnail">
    <a href="<?php the_permalink(); ?>">
        <?php echo use_placeholder(); ?>
    </a>    
  </div>
  <div class="col-lg-8">
   <header class="entry-header">
    <?php
      the_title( '<h2 class="entry-title"><a href="' . 
                esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
    ?>
    </header><!-- .entry-header -->
      
    <div class="post-date">
      <span>Posted On : <?php echo get_the_date(); ?> |  
          Category : <?php the_category( ', ' ); ?></span> 
    </div>  
      
    <div class="entry-content entry-excerpt">
      <?php the_excerpt(); ?>
    </div><!-- .entry-content -->
    
      
    <div class="entry-footer">
        <a href="<?php the_permalink(); ?>">
          Read More
        </a>
    </div>  
  </div>                
</div>
</article><!-- #post-<?php the_ID(); ?> -->
