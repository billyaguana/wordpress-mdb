<?php
    $cpost = get_post_type();
    //If you are using Custom Post Types with ACF
    /* 
    switch ($cpost) {
    case 'category':
        get_template_part( 'template-parts/archive', $cpost);
        break;
            
    case 'books':
        get_template_part( 'template-parts/archive', 'books');
        break;
            
    case 'sample type':
        get_template_part( 'template-parts/archive', $cpost);
        break;

    case 'sample type':
        get_template_part( 'template-parts/archive', $cpost);
        break;
            
        
    default:
        get_template_part( 'template-parts/archive', $cpost);
    }*/

?>
<?php if ( have_posts() ) : ?>
<?php
    /* Start the Loop */
    while ( have_posts() ) :
        the_post();

        /*
         * Include the Post-Type-specific template for the content.
         * If you want to override this in a child theme, then include a file
         * called content-___.php (where ___ is the Post Type name) and that will be used instead.
         */
        get_template_part( 'template-parts/archive', 'content_post');
        /* 
           //post_type = books
           get_template_part( 'template-parts/archive', 'books'); 
           create a file named : archive-books.php (loop + excerpt)
                                 content-books.php (single)    
        */

    endwhile;
?>        
    <div class="post-pagination  clearfix">
        <?php pp_pagination_nav(); ?>
    </div>

<?php endif; ?>