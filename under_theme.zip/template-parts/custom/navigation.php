<!--Navbar-->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top scrolling-navbar">
<div class="container">
    <!-- Links -->
    <?php
     wp_megamenu(array('theme_location' => 'top')); 
    ?>
    <!-- Links -->
</div>
</nav>
<!--/.Navbar--> 