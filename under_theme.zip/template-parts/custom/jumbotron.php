<?php 
    if(is_archive()) :
      $title = get_the_archive_title();
    elseif(is_page()) : 
      $title = get_the_title();
    elseif(is_single()) : 
      $title = get_the_title();
    elseif(is_404()) : 
      $title = "Page Not Found";
     elseif(is_search()) : 
      $title = "Search Page";
    endif;

?>
<div class="jumbotron p-0">
<div class="view p-5" style="background-image: url('<?php echo get_template_directory_uri() ?>/assets/images/img(134).jpg');"> 
<div class="mask rgba-black-strong"></div>        
<div class="caption container p-5">
    <h1 class="page-title text-center mt-5"><?php echo $title; ?></h1>    
</div>
</div>         
</div>