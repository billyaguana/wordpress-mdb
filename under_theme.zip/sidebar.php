<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package under_theme
 */
?>
<sidebar>
    
<aside class="widget category-widget">
    <h3 class="widget-title">Follow Us</h3>
<ul class="social-links">
 <li><a href="#"><i class="fab fa-facebook-square"></i></a></li>   
 <li><a href="#"><i class="fab fa-twitter-square"></i></a></li>  
 <li><a href="#"><i class="fas fa-envelope-square"></i></a></li>      
 <li><a href="#"><i class="fab fa-github-square"></i></a></li>  
 <li><a href="#"><i class="fas fa-phone-square"></i></a></li>      
    
    
    
</ul>   
</aside>    
    
<aside class="widget category-widget">
    <h3 class="widget-title">Post Categories</h3>

    <div class="list-group sidebar-list-group">
	  <?php
      $categories = get_categories( array(
          'parent'   => '0',
          'orderby' => 'name',
          'exclude' => '',
          'order'   => 'ASC',
          'hide_empty'   => '1'		  
      ) );
       
      foreach( $categories as $category ) {
          $category_link = esc_url(get_category_link( $category->term_id)); 
      ?>
      <a href="<?php echo $category_link; ?>" class="list-group-item d-flex justify-content-between align-items-center">
        <?php echo $category->name; ?>
        <span class="badge badge-primary badge-pill"><?php echo $category->count; ?></span>
      </a>
	  <?php } ?>    
    </div>
</aside>
    
<aside class="widget latest-post-widget">
    <h3 class="widget-title">Latest Posts</h3>
    <ul>
    <?php 
	   $query = new WP_Query('cat=()&posts_per_page=4'); 
	   if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
	?>  
        <li class="media">
            <div class="media-left">
            <a href="<?php the_permalink(); ?>" class="popular-img">
				<?php 
					if ( has_post_thumbnail() ) : 
						the_post_thumbnail($size = 'medium_large', ['class' => 'img-responsive responsive--full']); 
					else :
				?>
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/placeholder.jpg" alt="placeholder">
				<?php
					endif; 
				?>
            </a>
            </div>
            <div class="latest-post-content">
                <span><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
                <small><?php echo get_the_date(); ?></small>
            </div>
        </li>
	<?php 
        endwhile; 
        wp_reset_postdata();
        endif; 
    ?>        

    </ul>
</aside>    

<aside id="secondary" class="widget-area">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- #secondary -->
</sidebar>


